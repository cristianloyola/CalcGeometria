package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class rectangulo extends AppCompatActivity {
    private EditText etNum1Rectangulo;
    private EditText etNum2Rectangulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rectangulo);
        etNum1Rectangulo=(EditText)findViewById(R.id.etNum1Rectangulo);
        etNum2Rectangulo=(EditText)findViewById(R.id.etNum2Rectangulo);
    }
    public void cuadradoResultado(View view){
        int num=Integer.parseInt(etNum1Rectangulo.getText().toString());
        int num2=Integer.parseInt(etNum2Rectangulo.getText().toString());

        int resultadoArea=num*num2;
        int resultadoPerimetro=2*(num+num2);
        double resultadoDiagonal=(Math.sqrt((num+num)+(num2*num2)));

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent rectanguloRes=new Intent(this, rectanguloResultado.class );
        Bundle resAreaRect=new Bundle();
        resAreaRect.putInt("areaRectRes",resultadoArea);
        rectanguloRes.putExtras(resAreaRect);
        Bundle resPeriRect=new Bundle();
        resPeriRect.putInt("periRectRes",resultadoPerimetro);
        rectanguloRes.putExtras(resPeriRect);
        Bundle resDiagRect=new Bundle();
        resDiagRect.putDouble("diagRectRes",resultadoDiagonal);
        rectanguloRes.putExtras(resDiagRect);


        startActivity(rectanguloRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
}
