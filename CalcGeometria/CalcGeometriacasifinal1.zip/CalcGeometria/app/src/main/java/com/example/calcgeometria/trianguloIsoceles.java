package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class trianguloIsoceles extends AppCompatActivity {
    private EditText etNum1Tris;
    private EditText etNum2Tris;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulo_isoceles);
        etNum1Tris=(EditText)findViewById(R.id.etNum1Tris);
        etNum2Tris=(EditText)findViewById(R.id.etNum2Tris);
    }

    public void trisResultado(View view){
        int num=Integer.parseInt(etNum1Tris.getText().toString());
        int num2=Integer.parseInt(etNum2Tris.getText().toString());

        int resultadoArea=(num*num2)/2;
        int resultadoPerimetro=2*(num+num2);
        double resultadoDiagonal=(2*(num+num2))/2;

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent trisRes=new Intent(this, trISResultado.class );
        Bundle resAreaTris=new Bundle();
        resAreaTris.putInt("areaTrisRes",resultadoArea);
        trisRes.putExtras(resAreaTris);
        Bundle resPeriTris=new Bundle();
        resPeriTris.putInt("periTrisRes",resultadoPerimetro);
        trisRes.putExtras(resPeriTris);
        Bundle resDiagTris=new Bundle();
        resDiagTris.putDouble("diagTrisRes",resultadoDiagonal);
        trisRes.putExtras(resDiagTris);


        startActivity(trisRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, triangulos.class );
        startActivity(vMain);
    }
}
