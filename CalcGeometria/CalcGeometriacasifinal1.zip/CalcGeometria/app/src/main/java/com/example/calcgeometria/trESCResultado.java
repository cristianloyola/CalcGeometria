package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class trESCResultado extends AppCompatActivity {
    private EditText etResAreaTresc, etResPeriTresc2, etResDiaTresc;
    ImageView ivResTresc, ivtrescformula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tr_escresultado);
        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaTresc = (EditText) findViewById(R.id.etResAreaTresc);
        Bundle resAreaTrescR = getIntent().getExtras();
        etResAreaTresc.setText("" + df.format(resAreaTrescR.getDouble("areaTrescRes")) + " mt2");

        etResPeriTresc2 = (EditText) findViewById(R.id.etResPeriTresc2);
        Bundle resPeriTrescR = getIntent().getExtras();
        etResPeriTresc2.setText("" + df.format(resPeriTrescR.getDouble("periTrescRes")) + " mt");

        etResDiaTresc = (EditText) findViewById(R.id.etResDiaTresc);
        Bundle resDiagTrescR = getIntent().getExtras();
        etResDiaTresc.setText("" + df.format(resDiagTrescR.getDouble("diagTrescRes")) + " mt");

        ivResTresc = (ImageView) findViewById(R.id.ivResTresc);
        ivtrescformula = (ImageView) findViewById(R.id.ivtrescformula);
    }
    public void cambioImagenarea(View view) {
        ivResTresc.setImageResource(R.drawable.trianguloescalenoarea);
        ivtrescformula.setImageResource(R.drawable.formulaareatriangulo);
    }

    public void cambioImagenPerimetro(View view) {
        ivResTresc.setImageResource(R.drawable.trianguloescalenoperimetro);
        ivtrescformula.setImageResource(R.drawable.perimetrotrianguloescalenoformula);
    }

    public void cambioImagenDiagonal(View view) {
        ivResTresc.setImageResource(R.drawable.semiperimetrotriangulo);
        ivtrescformula.setImageResource(R.drawable.semiperimetrotrianguloformula);
    }


    public void volverMain(View view) {
        Intent vMain = new Intent(this, MainActivity.class);
        startActivity(vMain);
    }

    public void volverTresc(View view) {
        Intent vTresc = new Intent(this, trianguloEscaleno.class);
        startActivity(vTresc);
    }
}
