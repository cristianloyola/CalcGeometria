package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class romboResultado extends AppCompatActivity {
    private EditText etResAreaRombo,etResPeriRombo2;
    ImageView ivResRombo,ivromboformula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rombo_resultado);
        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaRombo=(EditText)findViewById(R.id.etResAreaRombo);
        Bundle resAreaRomboR=getIntent().getExtras();
        etResAreaRombo.setText(""+resAreaRomboR.getInt("areaRomboRes")+" mt2");

        etResPeriRombo2=(EditText)findViewById(R.id.etResPeriRombo2);
        Bundle resPeriRomboR=getIntent().getExtras();
        etResPeriRombo2.setText(""+resPeriRomboR.getInt("periRomboRes")+" mt");



        ivResRombo=(ImageView) findViewById(R.id.ivResRombo);
        ivromboformula=(ImageView) findViewById(R.id.ivromboformula);
    }
    public void cambioImagenarea(View view){
        ivResRombo.setImageResource(R.drawable.romboarea);
        ivromboformula.setImageResource(R.drawable.formulaarearombo);
    }
    public void cambioImagenPerimetro(View view){
        ivResRombo.setImageResource(R.drawable.romboperimetro);
        ivromboformula.setImageResource(R.drawable.perimetroromboformula);
    }





    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
    public void volverRombo(View view){
        Intent vRombo=new Intent(this, rombo.class );
        startActivity(vRombo);
    }

}