package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class rombo extends AppCompatActivity {
    private EditText etNum1Rombo;
    private EditText etNum2Rombo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rombo);
        etNum1Rombo=(EditText)findViewById(R.id.etNum1Rombo);
        etNum2Rombo=(EditText)findViewById(R.id.etNum2Rombo);
    }

    public void romboResultado(View view){
        int num=Integer.parseInt(etNum1Rombo.getText().toString());
        int num2=Integer.parseInt(etNum2Rombo.getText().toString());

        int resultadoArea=num*num2;
        int resultadoPerimetro=2*(num+num2);
        //double resultadoDiagonal=(Math.sqrt((num+num)+(num2*num2)));

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent romboRes=new Intent(this, romboResultado.class );
        Bundle resAreaRombo=new Bundle();
        resAreaRombo.putInt("areaRomboRes",resultadoArea);
        romboRes.putExtras(resAreaRombo);
        Bundle resPeriRombo=new Bundle();
        resPeriRombo.putInt("periRomboRes",resultadoPerimetro);
        romboRes.putExtras(resPeriRombo);
        Bundle resDiagRect=new Bundle();



        startActivity(romboRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
}
