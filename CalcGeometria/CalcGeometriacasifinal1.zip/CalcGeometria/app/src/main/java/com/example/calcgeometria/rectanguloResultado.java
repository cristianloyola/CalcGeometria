package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class rectanguloResultado extends AppCompatActivity {
    private EditText etResAreaRect,etResPeriRect2,etResDiagRect;
    ImageView ivResRect,ivrectformula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rectangulo_resultado);
        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaRect=(EditText)findViewById(R.id.etResAreaRect);
        Bundle resAreaRectR=getIntent().getExtras();
        etResAreaRect.setText(""+resAreaRectR.getInt("areaRectRes")+" mt2");

        etResPeriRect2=(EditText)findViewById(R.id.etResPeriRect2);
        Bundle resPeriRectR=getIntent().getExtras();
        etResPeriRect2.setText(""+resPeriRectR.getInt("periRectRes")+" mt");

        etResDiagRect=(EditText)findViewById(R.id.etResDiagRect);
        Bundle resDiagRectR=getIntent().getExtras();
        etResDiagRect.setText(""+df.format(resDiagRectR.getDouble("diagRectRes"))+" mt");

        ivResRect=(ImageView) findViewById(R.id.ivResRect);
        ivrectformula=(ImageView) findViewById(R.id.ivrectformula);

    }

    public void cambioImagenarea(View view){
        ivResRect.setImageResource(R.drawable.rectanguloarea);
        ivrectformula.setImageResource(R.drawable.arearectanguloformula);
    }
    public void cambioImagenPerimetro(View view){
        ivResRect.setImageResource(R.drawable.rectanguloperimetro);
        ivrectformula.setImageResource(R.drawable.perimetrorectanguloformula);
    }
    public void cambioImagenDiagonal(View view){
        ivResRect.setImageResource(R.drawable.rectangulodiagonal);
        ivrectformula.setImageResource(R.drawable.diagonalrectanguloformula);
    }




    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
    public void volverRectangulo(View view){
        Intent vRect=new Intent(this, rectangulo.class );
        startActivity(vRect);
    }
}
