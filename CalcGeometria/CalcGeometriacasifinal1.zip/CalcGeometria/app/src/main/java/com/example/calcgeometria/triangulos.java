package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class triangulos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulos);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
    public void siguienteTrianguloEq(View view){
        Intent siguiente=new Intent(this, trianguloEquilatero.class );
        startActivity(siguiente);
    }

    public void siguienteTrianguloIs(View view){
        Intent siguiente=new Intent(this, trianguloIsoceles.class );
        startActivity(siguiente);
    }
    public void siguienteTrianguloEsc(View view){
        Intent siguiente=new Intent(this, trianguloEscaleno.class );
        startActivity(siguiente);
    }
}
