package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class circuloResultado extends AppCompatActivity {
    private EditText etResAreaCirc,etResPeriCirc2,etResDiagCirc;
    ImageView ivResCirc,ivcircformula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circulo_resultado);
        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaCirc=(EditText)findViewById(R.id.etResAreaCirc);
        Bundle resAreaCircR=getIntent().getExtras();
        etResAreaCirc.setText(""+df.format(resAreaCircR.getDouble("areaCircRes"))+" mt2");

        etResPeriCirc2=(EditText)findViewById(R.id.etResPeriCirc2);
        Bundle resPeriCircR=getIntent().getExtras();
        etResPeriCirc2.setText(""+df.format(resPeriCircR.getDouble("periCircRes"))+" mt");

        etResDiagCirc=(EditText)findViewById(R.id.etResDiagCirc);
        Bundle resDiagCircR=getIntent().getExtras();
        etResDiagCirc.setText(""+df.format(resDiagCircR.getDouble("diagCircRes"))+" mt");

        ivResCirc=(ImageView) findViewById(R.id.ivResCirc);
        ivcircformula=(ImageView) findViewById(R.id.ivcircformula);


    }

    public void cambioImagenarea(View view){
        ivResCirc.setImageResource(R.drawable.areacirculo);
        ivcircformula.setImageResource(R.drawable.areacirculoformula);
    }
    public void cambioImagenPerimetro(View view){
        ivResCirc.setImageResource(R.drawable.perimetrocirculo);
        ivcircformula.setImageResource(R.drawable.perimetrocirculoformula);
    }
    public void cambioImagenDiagonal(View view){
        ivResCirc.setImageResource(R.drawable.diametrocirculoimg);
        ivcircformula.setImageResource(R.drawable.diametrocirculoformula);
    }




    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
    public void volverCirculo(View view){
        Intent vCirc=new Intent(this, circulo.class );
        startActivity(vCirc);
    }
}
