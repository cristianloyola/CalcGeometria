package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class trianguloEquilatero extends AppCompatActivity {
    private EditText etNum1Treq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulo_equilatero);
        etNum1Treq=(EditText)findViewById(R.id.etNum1Treq);
    }

    public void trEqResultado(View view){
        int num=Integer.parseInt(etNum1Treq.getText().toString());
        //int num2=Integer.parseInt(etNum1Cuadrado1.getText().toString());

        double resultadoArea=(Math.sqrt(3)/4)*(num*num);
        double resultadoPerimetro=num*3;
        double resultadoSemiPerimetro=(3*num)/2;

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent trEqRes=new Intent(this, trEqResultado.class );
        Bundle resAreaTreq=new Bundle();
        resAreaTreq.putDouble("areaTreqRes",resultadoArea);
        trEqRes.putExtras(resAreaTreq);
        Bundle resPeriTreq=new Bundle();
        resPeriTreq.putDouble("periTreqRes",resultadoPerimetro);
        trEqRes.putExtras(resPeriTreq);
        Bundle resDiagTreq=new Bundle();
        resDiagTreq.putDouble("diagTreqRes",resultadoSemiPerimetro);
        trEqRes.putExtras(resDiagTreq);


        startActivity(trEqRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }

}
