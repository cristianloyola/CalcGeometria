package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class circulo extends AppCompatActivity {
    private EditText etNum1Circulo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circulo);
        etNum1Circulo=(EditText)findViewById(R.id.etNum1Circulo);
    }

    public void circuloResultado(View view){
        int num=Integer.parseInt(etNum1Circulo.getText().toString());
        //int num2=Integer.parseInt(etNum1Cuadrado1.getText().toString());

        double resultadoArea=Math.PI*(num*num);
        double resultadoPerimetro=2*Math.PI*num;
        double resultadoDiagonal=(2*num);

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent circuloRes=new Intent(this, circuloResultado.class );
        Bundle resAreaCirc=new Bundle();
        resAreaCirc.putDouble("areaCircRes",resultadoArea);
        circuloRes.putExtras(resAreaCirc);
        Bundle resPeriCirc=new Bundle();
        resPeriCirc.putDouble("periCircRes",resultadoPerimetro);
        circuloRes.putExtras(resPeriCirc);
        Bundle resDiagCirc=new Bundle();
        resDiagCirc.putDouble("diagCircRes",resultadoDiagonal);
        circuloRes.putExtras(resDiagCirc);


        startActivity(circuloRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
}
