package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void siguienteCuadrado(View view){
        Intent siguiente=new Intent(this, cuadrado.class );
        startActivity(siguiente);
    }

    public void siguienteRectangulo(View view){
        Intent siguiente=new Intent(this, rectangulo.class );
        startActivity(siguiente);
    }
    public void siguienteCirculo(View view){
        Intent siguiente=new Intent(this, circulo.class );
        startActivity(siguiente);
    }
    public void siguienteTriangulo(View view){
        Intent siguiente=new Intent(this, triangulos.class );
        startActivity(siguiente);
    }
}
