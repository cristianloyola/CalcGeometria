package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import static java.lang.Math.round;

public class cuadrado extends AppCompatActivity {
    private EditText  etNum1Cuadrado1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuadrado);
        etNum1Cuadrado1=(EditText)findViewById(R.id.etNum1Cuadrado1);
    }

    public void cuadradoResultado(View view){
        int num=Integer.parseInt(etNum1Cuadrado1.getText().toString());
        //int num2=Integer.parseInt(etNum1Cuadrado1.getText().toString());

        int resultadoArea=num*num;
        int resultadoPerimetro=num*4;
        double resultadoDiagonal=(Math.sqrt(2)*num);

       //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent cuadradoRes=new Intent(this, cuadradoResultado.class );
        Bundle resAreaCuad=new Bundle();
        resAreaCuad.putInt("areaCuadRes",resultadoArea);
        cuadradoRes.putExtras(resAreaCuad);
        Bundle resPeriCuad=new Bundle();
        resPeriCuad.putInt("periCuadRes",resultadoPerimetro);
        cuadradoRes.putExtras(resPeriCuad);
        Bundle resDiagCuad=new Bundle();
        resDiagCuad.putDouble("diagCuadRes",resultadoDiagonal);
        cuadradoRes.putExtras(resDiagCuad);


        startActivity(cuadradoRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }

}
