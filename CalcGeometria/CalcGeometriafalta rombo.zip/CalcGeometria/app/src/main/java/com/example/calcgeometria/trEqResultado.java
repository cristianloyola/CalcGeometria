package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class trEqResultado extends AppCompatActivity {
    private EditText etResAreaTreq, etResPeriTreq2, etResDiaTreq;
    ImageView ivResTreq, ivtreqformula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tr_eq_resultado);


        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaTreq = (EditText) findViewById(R.id.etResAreaTreq);
        Bundle resAreaTreqR = getIntent().getExtras();
        etResAreaTreq.setText("" + df.format(resAreaTreqR.getDouble("areaTreqRes")) + " mt2");

        etResPeriTreq2 = (EditText) findViewById(R.id.etResPeriTreq2);
        Bundle resPeriTreqR = getIntent().getExtras();
        etResPeriTreq2.setText("" + df.format(resPeriTreqR.getDouble("periTreqRes")) + " mt");

        etResDiaTreq = (EditText) findViewById(R.id.etResDiaTreq);
        Bundle resDiagTreqR = getIntent().getExtras();
        etResDiaTreq.setText("" + df.format(resDiagTreqR.getDouble("diagTreqRes")) + " mt");

        ivResTreq = (ImageView) findViewById(R.id.ivResTreq);
        ivtreqformula = (ImageView) findViewById(R.id.ivtreqformula);


    }

    public void cambioImagenarea(View view) {
        ivResTreq.setImageResource(R.drawable.trianguloequilateroarea);
        ivtreqformula.setImageResource(R.drawable.areatrianguloequilatero);
    }

    public void cambioImagenPerimetro(View view) {
        ivResTreq.setImageResource(R.drawable.trianguloequilateroperimetro);
        ivtreqformula.setImageResource(R.drawable.perimetrotrianguloequilateroformula);
    }

    public void cambioImagenDiagonal(View view) {
        ivResTreq.setImageResource(R.drawable.semiperimetrotriangulo);
        ivtreqformula.setImageResource(R.drawable.semiperimetrotrianguloformula);
    }


    public void volverMain(View view) {
        Intent vMain = new Intent(this, MainActivity.class);
        startActivity(vMain);
    }

    public void volverTreq(View view) {
        Intent vTreq = new Intent(this, trianguloEquilatero.class);
        startActivity(vTreq);
    }

}
