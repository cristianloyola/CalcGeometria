package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class trianguloEscaleno extends AppCompatActivity {
    private EditText etNum1Tresc;
    private EditText etNum2Tresc;
    private EditText etNum3Tresc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulo_escaleno);
        etNum1Tresc=(EditText)findViewById(R.id.etNum1Tresc);
        etNum2Tresc=(EditText)findViewById(R.id.etNum2Tresc);
        etNum3Tresc=(EditText)findViewById(R.id.etNum3Tresc);
    }
    public void trescResultado(View view){
        int num=Integer.parseInt(etNum1Tresc.getText().toString());
        int num2=Integer.parseInt(etNum2Tresc.getText().toString());
        int num3=Integer.parseInt(etNum3Tresc.getText().toString());

        double resultadoArea=(Math.sqrt((num+num2+num3)/2)*(((num+num2+num3)/2)-num)*(((num+num2+num3)/2)-num2)*(((num+num2+num3)/2)-num3));
        int resultadoPerimetro=(num+num2+num3);
        double resultadoDiagonal=(num+num2+num3)/2;

        //String resultadoDiagonalTxt=String.format("%.2f",resultadoDiagonal);

        Intent trescRes=new Intent(this, trESCResultado.class );
        Bundle resAreaTresc=new Bundle();
        resAreaTresc.putDouble("areaTrescRes",resultadoArea);
        trescRes.putExtras(resAreaTresc);
        Bundle resPeriTresc=new Bundle();
        resPeriTresc.putInt("periTrescRes",resultadoPerimetro);
        trescRes.putExtras(resPeriTresc);
        Bundle resDiagTresc=new Bundle();
        resDiagTresc.putDouble("diagTrescRes",resultadoDiagonal);
        trescRes.putExtras(resDiagTresc);


        startActivity(trescRes);
    }
    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }

}
