package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.text.DecimalFormat;

public class trISResultado extends AppCompatActivity {
    private EditText etResAreaTris, etResPeriTris2, etResDiaTris;
    ImageView ivResTris, ivtrisformula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tr_isresultado);

        DecimalFormat df = new DecimalFormat("####0.00");
        //redondeo y formateo double

        etResAreaTris = (EditText) findViewById(R.id.etResAreaTris);
        Bundle resAreaTrisR = getIntent().getExtras();
        etResAreaTris.setText("" + df.format(resAreaTrisR.getDouble("areaTrisRes")) + " mt2");

        etResPeriTris2 = (EditText) findViewById(R.id.etResPeriTris2);
        Bundle resPeriTrisR = getIntent().getExtras();
        etResPeriTris2.setText("" + df.format(resPeriTrisR.getDouble("periTrisRes")) + " mt");

        etResDiaTris = (EditText) findViewById(R.id.etResDiaTris);
        Bundle resDiagTrisR = getIntent().getExtras();
        etResDiaTris.setText("" + df.format(resDiagTrisR.getDouble("diagTrisRes")) + " mt");

        ivResTris = (ImageView) findViewById(R.id.ivResTris);
        ivtrisformula = (ImageView) findViewById(R.id.ivtrisformula);
    }

    public void cambioImagenarea(View view) {
        ivResTris.setImageResource(R.drawable.trianguloisoscelesarea);
        ivtrisformula.setImageResource(R.drawable.areatrianguloisoceles);
    }

    public void cambioImagenPerimetro(View view) {
        ivResTris.setImageResource(R.drawable.trianguloisoscelesperimetro);
        ivtrisformula.setImageResource(R.drawable.perimetrotrianguloisoscelesformula);
    }

    public void cambioImagenDiagonal(View view) {
        ivResTris.setImageResource(R.drawable.semiperimetrotriangulo);
        ivtrisformula.setImageResource(R.drawable.semiperimetrotrianguloformula);
    }


    public void volverMain(View view) {
        Intent vMain = new Intent(this, MainActivity.class);
        startActivity(vMain);
    }

    public void volverTris(View view) {
        Intent vTris = new Intent(this, trianguloIsoceles.class);
        startActivity(vTris);
    }
}
