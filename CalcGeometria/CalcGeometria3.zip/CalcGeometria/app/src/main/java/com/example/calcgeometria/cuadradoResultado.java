package com.example.calcgeometria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.DecimalFormat;

public class cuadradoResultado extends AppCompatActivity {
    private EditText etResAreaCuad,etResPeriCuad2,etResDiagCuad;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuadrado_resultado);
        DecimalFormat df = new DecimalFormat("####0.00");

        etResAreaCuad=(EditText)findViewById(R.id.etResAreaCuad);
        Bundle resAreaCuadR=getIntent().getExtras();
        etResAreaCuad.setText(""+resAreaCuadR.getInt("areaCuadRes")+" mt2");

        etResPeriCuad2=(EditText)findViewById(R.id.etResPeriCuad2);
        Bundle resPeriCuadR=getIntent().getExtras();
        etResPeriCuad2.setText(""+resPeriCuadR.getInt("periCuadRes")+" mt");

        etResDiagCuad=(EditText)findViewById(R.id.etResDiagCuad);
        Bundle resDiagCuadR=getIntent().getExtras();
        etResDiagCuad.setText(""+df.format(resDiagCuadR.getDouble("diagCuadRes"))+" mt");


    }




    public void volverMain(View view){
        Intent vMain=new Intent(this, MainActivity.class );
        startActivity(vMain);
    }
    public void volverCuadrado(View view){
        Intent vCuad=new Intent(this, cuadrado.class );
        startActivity(vCuad);
    }
}
